Implement a new kind of game object as rewarding coin with collision detection.

Create a coins rewarding mechanism to let hero collect them.
