Refactor the collision code into a generic method.

Rewrite the platform and obstacle detection code into a generic method that detect between hero and any object with specific category.
