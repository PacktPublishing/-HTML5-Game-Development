Implement a new kind of game object as an obstacle.

Implement an obstacle game object so player need to avoid hitting on it later.
