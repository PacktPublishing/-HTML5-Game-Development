Collision between platforms and hero.

Loop through all platforms object and detect if the hero hits on any one of them

