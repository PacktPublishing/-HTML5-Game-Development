Collision between obstacles and hero.

Loop through all obstacles and detect collision between obstacles and hero.
