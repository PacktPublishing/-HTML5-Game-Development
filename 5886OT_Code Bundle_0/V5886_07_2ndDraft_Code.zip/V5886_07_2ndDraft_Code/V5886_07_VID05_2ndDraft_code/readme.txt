Display a file loading progress bar to show how much left until the game starts.
