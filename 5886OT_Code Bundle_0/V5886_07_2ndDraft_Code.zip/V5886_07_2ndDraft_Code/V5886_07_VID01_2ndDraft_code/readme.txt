Prepare both static graphics file and spritesheet file for animation.
