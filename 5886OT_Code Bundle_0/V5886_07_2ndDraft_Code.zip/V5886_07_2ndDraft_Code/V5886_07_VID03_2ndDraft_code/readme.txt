Integrate the exported sprite sheet PNG file into the game and use the frame data object.
