Make the platform scale with dynamic width.
