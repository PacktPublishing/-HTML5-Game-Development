Put the platform graphics which follows the camera and a background image that is fixed in position.
