Make the hero able the jump from one platform to another platform.
