Add a gravity velocity to the hero and use Ticker interval to apply the gravity to the y position of the hero.
