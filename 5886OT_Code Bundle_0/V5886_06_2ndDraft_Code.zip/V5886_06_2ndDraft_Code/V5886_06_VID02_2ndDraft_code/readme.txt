The falling hero will now stands on platform after the hero collides with it.
