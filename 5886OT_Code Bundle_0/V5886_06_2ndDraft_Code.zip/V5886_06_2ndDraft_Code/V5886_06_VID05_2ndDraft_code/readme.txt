Make the game over when the hero hits on the obstacles or falls to the bottom.
