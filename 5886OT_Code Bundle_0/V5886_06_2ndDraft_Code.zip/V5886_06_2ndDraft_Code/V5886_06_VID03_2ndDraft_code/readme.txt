Add a x velocity to make the hero runs and use a camera to follow the hero.
