Record the current score to display it in game over scene and show the highest ever scores.
