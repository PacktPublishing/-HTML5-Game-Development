Create a game over scene after the game so we can use this scene to display score information in future sections.
