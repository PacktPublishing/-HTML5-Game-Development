Create a menu scene at the beginning that starts the game when it is clicked anywhere.
