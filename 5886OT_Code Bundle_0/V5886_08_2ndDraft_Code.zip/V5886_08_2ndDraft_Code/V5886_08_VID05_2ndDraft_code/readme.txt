Decorating the web page of the game with a how-to-play guide and leader board so it is ready for others to play.
