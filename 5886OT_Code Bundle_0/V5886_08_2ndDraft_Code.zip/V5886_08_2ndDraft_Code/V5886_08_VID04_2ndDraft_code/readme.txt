Display a leader board with eight highest scores in the game over scene.
