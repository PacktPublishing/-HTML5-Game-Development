File skeleton with empty files. 
The EaselJS game library file is placed inside vendors/