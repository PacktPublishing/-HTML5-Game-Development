Implement a Tile class that contain a rectangle shape and a numbered text.
The tile is placed on stage in random position.